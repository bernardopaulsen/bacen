# bacen

## bacen.get

### Parameters
- number - str - Series number in BACEN SGS
- start - str - Initial date for the series (DD/MM/YYY)
- end - str - Final date for the series (DD/MM/YYY)
### Returns
- pandas.DataFrame
